(ns acme.cache_policy-distractor)

(defn distractor-policy []
  {:ttl-ms 125
   :fixture "distractor-f01"})
