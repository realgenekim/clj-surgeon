Synthetic routing fixture.
