(ns acme.cache_policy)

(defn cache-policy []
  {:ttl-ms 250
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
