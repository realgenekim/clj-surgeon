(ns acme.retry_policy-distractor)

(defn distractor-policy []
  {:attempts 2
   :fixture "distractor-f02"})
