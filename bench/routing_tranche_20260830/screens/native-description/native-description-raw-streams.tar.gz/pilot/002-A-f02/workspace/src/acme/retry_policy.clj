(ns acme.retry_policy)

(defn retry-policy []
  {:attempts 4
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
