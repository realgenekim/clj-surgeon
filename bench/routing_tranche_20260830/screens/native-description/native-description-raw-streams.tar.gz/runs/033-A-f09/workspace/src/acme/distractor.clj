(ns acme.report_policy-distractor)

(defn distractor-policy []
  {:format "compact"
   :fixture "distractor-f09"})
