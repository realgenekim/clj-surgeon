(ns acme.report_policy)

(defn report-policy []
  {:format "expanded"
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
