(ns acme.batch_policy)

(defn batch-policy []
  {:batch-size 24
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
