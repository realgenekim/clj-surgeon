(ns acme.batch_policy-distractor)

(defn distractor-policy []
  {:batch-size 16
   :fixture "distractor-f06"})
