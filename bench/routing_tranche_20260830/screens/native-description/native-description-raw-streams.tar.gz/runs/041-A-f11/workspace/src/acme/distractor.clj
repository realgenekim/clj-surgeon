(ns acme.sync_policy-distractor)

(defn distractor-policy []
  {:strategy :lazy
   :fixture "distractor-f11"})
