(ns acme.sync_policy)

(defn sync-policy []
  {:strategy :eager
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
