(ns acme.socket_policy-distractor)

(defn distractor-policy []
  {:timeout-ms 300
   :fixture "distractor-f07"})
