(ns acme.socket_policy)

(defn socket-policy []
  {:timeout-ms 450
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
