(ns acme.worker_policy)

(defn worker-policy []
  {:workers 5
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
