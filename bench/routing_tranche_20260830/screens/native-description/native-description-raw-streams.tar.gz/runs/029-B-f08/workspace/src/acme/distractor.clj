(ns acme.worker_policy-distractor)

(defn distractor-policy []
  {:workers 3
   :fixture "distractor-f08"})
