(ns acme.queue_policy-distractor)

(defn distractor-policy []
  {:capacity 64
   :fixture "distractor-f03"})
