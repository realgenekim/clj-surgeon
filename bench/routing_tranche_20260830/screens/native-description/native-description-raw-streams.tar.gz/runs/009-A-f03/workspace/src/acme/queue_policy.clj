(ns acme.queue_policy)

(defn queue-policy []
  {:capacity 96
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
