(ns acme.audit_policy-distractor)

(defn distractor-policy []
  {:profile "legacy"
   :fixture "distractor-f04"})
