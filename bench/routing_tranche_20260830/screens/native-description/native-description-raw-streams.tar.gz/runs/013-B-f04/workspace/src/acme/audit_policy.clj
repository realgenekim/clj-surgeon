(ns acme.audit_policy)

(defn audit-policy []
  {:profile "current"
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
