(ns acme.health_policy)

(defn health-policy []
  {:interval-ms 900
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
