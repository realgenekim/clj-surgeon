(ns acme.health_policy-distractor)

(defn distractor-policy []
  {:interval-ms 700
   :fixture "distractor-f12"})
