(ns acme.token_policy)

(defn token-policy []
  {:window 48
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
