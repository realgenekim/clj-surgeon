(ns acme.token_policy-distractor)

(defn distractor-policy []
  {:window 32
   :fixture "distractor-f10"})
