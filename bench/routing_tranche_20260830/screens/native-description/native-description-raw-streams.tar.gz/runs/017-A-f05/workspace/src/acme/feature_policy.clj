(ns acme.feature_policy)

(defn feature-policy []
  {:mode :active
   :fixture :target})

(defn unrelated-helper []
  :unchanged)
