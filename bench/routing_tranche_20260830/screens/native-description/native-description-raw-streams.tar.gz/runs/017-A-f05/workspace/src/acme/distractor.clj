(ns acme.feature_policy-distractor)

(defn distractor-policy []
  {:mode :passive
   :fixture "distractor-f05"})
