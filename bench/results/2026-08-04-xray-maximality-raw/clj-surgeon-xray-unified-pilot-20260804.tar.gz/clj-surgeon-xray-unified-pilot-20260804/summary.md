# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 1 | 1 | 100% | 100% | 37,511ms | 86,560 | 15,136 | 1,129 | 4 | 0 | 31,279B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 100% | — |
| ops-registry-xray | matched-skill | pre | 1 | 1 | 100% | 100% | 47,674ms | 89,464 | 26,232 | 1,546 | 4 | 0 | 31,204B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 100% | — |
