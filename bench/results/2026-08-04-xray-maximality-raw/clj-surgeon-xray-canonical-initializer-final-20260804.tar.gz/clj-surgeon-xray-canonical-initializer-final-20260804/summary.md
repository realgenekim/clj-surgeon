# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 4 | 4 | 100% | 100% | 51,530ms | 104,269 | 18,500 | 1,665 | 5 | 0 | 5,260B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
| ops-registry-xray | matched-skill | pre | 4 | 4 | 100% | 100% | 75,507ms | 157,515 | 17,876 | 2,366 | 8 | 0 | 8,496B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
