# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 4 | 4 | 100% | 100% | 24,462ms | 44,480 | 7,360 | 802 | 2 | 0 | 1,446B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
| ops-registry-xray | matched-skill | pre | 4 | 4 | 100% | 100% | 23,764ms | 44,702 | 9,630 | 723 | 2 | 0 | 1,414B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
