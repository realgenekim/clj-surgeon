# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 1 | 1 | 100% | 100% | 89,875ms | 166,014 | 16,766 | 2,321 | 8 | 0 | 8,606B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
| ops-registry-xray | matched-skill | pre | 1 | 1 | 100% | 100% | 62,603ms | 103,518 | 20,062 | 1,504 | 5 | 0 | 5,041B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
