# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 1 | 1 | 100% | 100% | 53,712ms | 88,128 | 19,776 | 1,660 | 4 | 0 | 31,618B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 100% | — |
| ops-registry-xray | matched-skill | pre | 1 | 1 | 100% | 100% | 58,373ms | 144,665 | 22,809 | 2,106 | 7 | 0 | 8,126B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
