# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 4 | 4 | 100% | 100% | 43,805ms | 94,241 | 18,302 | 1,562 | 5 | 0 | 5,146B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
| ops-registry-xray | matched-skill | pre | 4 | 4 | 100% | 100% | 47,626ms | 103,588 | 19,201 | 1,619 | 5 | 0 | 5,267B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
