# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 1 | 1 | 100% | 100% | 52,878ms | 126,497 | 23,841 | 1,942 | 6 | 0 | 8,759B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
| ops-registry-xray | matched-skill | pre | 1 | 1 | 100% | 100% | 54,880ms | 125,044 | 23,412 | 1,828 | 6 | 0 | 7,563B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
