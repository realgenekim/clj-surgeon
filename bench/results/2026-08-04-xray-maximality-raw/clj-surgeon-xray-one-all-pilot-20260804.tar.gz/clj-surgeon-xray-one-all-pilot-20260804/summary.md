# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 1 | 1 | 100% | 100% | 82,902ms | 163,021 | 18,893 | 2,197 | 8 | 0 | 8,260B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
| ops-registry-xray | matched-skill | pre | 1 | 1 | 100% | 100% | 112,503ms | 166,884 | 25,828 | 2,656 | 8 | 0 | 8,916B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 0% | — |
