# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 4 | 4 | 100% | 100% | 102,187ms | 230,472 | 35,669 | 3,374 | 11 | 0 | 19,181B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 25% | — |
| ops-registry-xray | matched-skill | pre | 4 | 4 | 100% | 100% | 83,916ms | 212,366 | 26,987 | 2,756 | 10 | 0 | 30,584B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 50% | — |
