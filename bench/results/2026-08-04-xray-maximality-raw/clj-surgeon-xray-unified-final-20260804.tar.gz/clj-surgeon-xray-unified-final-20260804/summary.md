# Clean Codex benchmark summary

Correctness is a gate. Efficiency medians include only correct runs. Token counts are the final cumulative usage reported by each Codex session.

| Task | Context | Version | n | Efficiency n | Correct | Exact presentation | Median wall | Median input | Median uncached | Median output | Shell calls | File changes | Source output | Skill read | q | xray | partition-all | edit | expr | First source edit | Text reader | show-form | Separate plan/apply |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ops-registry-xray | matched-skill | post | 4 | 4 | 100% | 100% | 68,980ms | 143,640 | 18,133 | 2,070 | 7 | 0 | 12,408B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 25% | — |
| ops-registry-xray | matched-skill | pre | 4 | 4 | 100% | 100% | 75,184ms | 170,596 | 24,420 | 2,693 | 8 | 0 | 12,638B | 100% | 0% | 100% | 0% | 0% | 100% | 0% | 0% | 25% | — |
