(ns clj-surgeon.help-test
  (:require
   [babashka.process :as proc]
   [clj-surgeon.core :as core]
   [clojure.edn :as edn]
   [clojure.java.io :as io]
   [clojure.string :as str]
   [clojure.test :refer [deftest is testing]]))

;; ============================================================
;; resolve-op
;; ============================================================

(deftest resolve-op-canonical-ops
  (testing "canonical ops resolve to themselves"
    (is (= :ls (core/resolve-op :ls)))
    (is (= :ls-tree (core/resolve-op :ls-tree)))
    (is (= :extract (core/resolve-op :extract)))
    (is (= :cljc-merge (core/resolve-op :cljc-merge)))))

(deftest resolve-op-aliases
  (testing "aliases resolve to canonical"
    (is (= :ls (core/resolve-op :outline)))
    (is (= :ls-tree (core/resolve-op :tree)))
    (is (= :ls-tree (core/resolve-op :map)))
    (is (= :ls-tree (core/resolve-op :outline-tree)))
    (is (= :show-form (core/resolve-op :cat)))
    (is (= :show-form (core/resolve-op "cat")))
    (is (= :find-subform (core/resolve-op :match-form)))
    (is (= :find-subform (core/resolve-op "match-form")))
    (is (= :find-subform (core/resolve-op :grep-form)))
    (is (= :find-subform (core/resolve-op "grep-form")))
    (is (= :lens (core/resolve-op :q)))
    (is (= :lens (core/resolve-op "q")))
    (is (= :mv (core/resolve-op :mv-with-deps)))
    (is (= :mv (core/resolve-op "mv-with-deps")))))

(deftest resolve-op-unknown
  (testing "unknown ops return nil"
    (is (nil? (core/resolve-op :bogus)))
    (is (nil? (core/resolve-op :nope)))))

(deftest resolve-op-string-ops
  (testing "bare string ops (CLI value without leading colon) resolve like keywords"
    ;; Regression: `clj-surgeon :op ls-tree` parses the value as the string
    ;; "ls-tree"; contains? on the sorted-map registry then threw
    ;; ClassCastException (Keyword vs String) instead of dispatching.
    (is (= :ls-tree (core/resolve-op "ls-tree")))
    (is (= :ls (core/resolve-op "ls")))
    (is (= :ls-tree (core/resolve-op "tree")))
    (is (= :ls (core/resolve-op "outline")))))

(deftest resolve-op-non-keyword-junk-is-nil-not-crash
  (testing "nil and unknown strings return nil instead of throwing"
    (is (nil? (core/resolve-op nil)))
    (is (nil? (core/resolve-op "bogus")))
    (is (nil? (core/resolve-op 42)))))

(deftest parse-args-then-resolve-op-documented-usage
  (testing "the documented CLI invocation `:op ls-tree` resolves end to end"
    (is (= :ls-tree (core/resolve-op (:op (core/parse-args [":op" "ls-tree"])))))
    (is (= :ls-tree (core/resolve-op (:op (core/parse-args [":op" ":ls-tree"])))))))

(deftest dispatch-string-op-ls-tree-documented-usage
  (testing "parse-args -> resolve-op -> run accepts the documented bare string op"
    (let [opts (core/parse-args [":op" "ls-tree" ":dir" "src"])]
      (is (= "ls-tree" (:op opts)))
      (is (= :ls-tree (core/resolve-op (:op opts))))
      (let [out (with-out-str (core/run opts))]
        (is (str/includes? out "clj_surgeon/core.clj"))
        (is (str/includes? out "ns: clj-surgeon.core"))))))

(deftest dispatch-keyword-op-ls-tree
  (testing "parse-args -> resolve-op -> run still accepts keyword ops"
    (let [opts (core/parse-args [":op" ":ls-tree" ":dir" "src"])]
      (is (= :ls-tree (:op opts)))
      (is (= :ls-tree (core/resolve-op (:op opts))))
      (let [out (with-out-str (core/run opts))]
        (is (str/includes? out "clj_surgeon/core.clj"))
        (is (str/includes? out "ns: clj-surgeon.core"))))))

(deftest dispatch-unknown-ops-return-error-maps-not-exceptions
  (testing "unknown bare string op returns a clean EDN error"
    (let [result (-> (with-out-str (core/run (core/parse-args [":op" "bogus"])))
                     edn/read-string)]
      (is (= :unknown-operation (:error-type result)))
      (is (str/includes? (:error result) "Unknown op: bogus"))
      (is (str/includes? (:error result) ":cat"))
      (is (str/includes? (:error result) ":match-form"))
      (is (not (str/includes? (:error result) ":show-form")))
      (is (not (str/includes? (:error result) ":find-subform")))
      (is (= "clj-surgeon :op :help" (:usage result)))))
  (testing "unknown keyword op returns a clean EDN error"
    (let [result (-> (with-out-str (core/run (core/parse-args [":op" ":bogus"])))
                     edn/read-string)]
      (is (= :unknown-operation (:error-type result)))
      (is (str/includes? (:error result) "Unknown op: :bogus"))
      (is (= "clj-surgeon :op :help" (:usage result))))))

;; ============================================================
;; ops-registry completeness
;; ============================================================

(deftest registry-has-all-ops
  (testing "registry contains every canonical op"
    (let [expected #{:ls :ls-tree :show-form :mv :declares :deps :topo
                     :ls-extract :ls-deps
                     :rename-ns :rename-ns!
                     :fix-declares :fix-declares!
                     :extract :extract! :undo-extract!
                     :find-subform :lens :xray :edit :change :change! :undo-change!
                     :replace-subform :replace-subform!
                     :cljc-merge :cljc-split :cljc-add-require :cljc-analyze}]
      (is (= expected (set (keys core/ops-registry)))))))

(deftest registry-entries-have-required-keys
  (testing "every entry has :handler, :desc, :args, :examples, :category"
    (doseq [[op-key op-def] core/ops-registry]
      (is (fn? (:handler op-def)) (str op-key " missing :handler"))
      (is (string? (:desc op-def)) (str op-key " missing :desc"))
      (is (map? (:args op-def)) (str op-key " missing :args"))
      (is (vector? (:examples op-def)) (str op-key " missing :examples"))
      (is (#{:read :write :cljc} (:category op-def)) (str op-key " invalid :category")))))

(deftest registry-pairs-are-symmetric
  (testing "plan/execute pairs point at each other"
    (doseq [[op-key {:keys [pair]}] core/ops-registry
            :when pair]
      (is (contains? core/ops-registry pair)
          (str op-key " :pair " pair " not in registry"))
      (is (= op-key (:pair (get core/ops-registry pair)))
          (str op-key " and " pair " are not symmetric")))))

;; ============================================================
;; format-global-help
;; ============================================================

(deftest global-help-contains-the-preferred-caller-surface
  (let [help (core/format-global-help core/ops-registry)]
    (testing "uses the preferred structural read names"
      (is (re-find #"(?m)^    cat\s" help))
      (is (re-find #"(?m)^    match-form\s" help))
      (is (not (re-find #"(?m)^    show-form\s" help)))
      (is (not (re-find #"(?m)^    find-subform\s" help)))
      (is (not (re-find #"(?m)^    lens\s" help))))
    (testing "contains category headers"
      (is (str/includes? help "Read-only"))
      (is (str/includes? help "Write"))
      (is (str/includes? help "CLJC")))
    (testing "contains usage and MCP-first agent routing"
      (is (str/includes? help "Usage:"))
      (is (str/includes? help "clj-surgeon :op :help"))
      (is (str/includes? help "Prefer persistent MCP inspect_clojure"))
      (is (str/includes? help "apply_clojure_changes"))
      (is (str/includes? help
                         "Use this process-starting CLI when MCP is unavailable")))
    (testing "contains quick start examples"
      (is (str/includes? help "Quick start:"))
      (is (str/includes? help
                         ":op :cat :file src/my/ns.clj :contains 'distinctive text'")))
    (testing "does not make the false only-bang-ops-write claim"
      (is (not (str/includes? help "only ! variants write files")))
      (is (str/includes? help ":mv writes unless :dry-run true")))))

(deftest global-help-excludes-aliases
  (let [help (core/format-global-help core/ops-registry)]
    (testing "aliases appear in parens, not as separate lines"
      ;; "outline" should appear as "(aliases: outline)" not as a left-column entry
      ;; Count how many times "outline" appears as a command name at start of line
      (let [lines (str/split-lines help)
            cmd-lines (filter #(re-find #"^\s{4}\S" %) lines)]
        (is (not (some #(re-find #"^\s{4}outline\s" %) cmd-lines))
            "alias 'outline' should not appear as its own command line")))))

(deftest global-help-op-names-resolve
  (let [help (core/format-global-help core/ops-registry)
        help-op-names (->> (str/split-lines help)
                           (keep #(second (re-matches #"\s{4}([a-z][a-z0-9!-]*)\s{2,}.+" %)))
                           (remove #{"clj-surgeon"})
                           set)]
    (testing "every op name printed in global help resolves from the parser's string form"
      (doseq [op-name help-op-names]
        (is (some? (core/resolve-op op-name))
            (str "global help prints unresolved op " op-name))))))

;; ============================================================
;; format-op-help
;; ============================================================

(deftest op-help-shows-required-args
  (let [help (core/format-op-help :extract (get core/ops-registry :extract))]
    (testing "shows (required) marker"
      (is (str/includes? help "(required)"))
      (is (str/includes? help ":file"))
      (is (str/includes? help ":forms"))
      (is (str/includes? help ":to")))
    (testing "shows see-also pair"
      (is (str/includes? help "See also: :op extract!")))
    (testing "shows examples"
      (is (str/includes? help "Examples:")))))

(deftest op-help-shows-optional-args
  (let [help (core/format-op-help :deps (get core/ops-registry :deps))]
    (testing ":form arg is optional (no required marker)"
      (is (str/includes? help ":form"))
      ;; :file is required, :form is not — check both appear
      (is (str/includes? help "(required) Clojure source file"))
      ;; :form line should NOT have (required)
      (let [form-line (->> (str/split-lines help)
                           (filter #(str/includes? % ":form"))
                           first)]
        (is (not (str/includes? form-line "(required)"))
            ":form should be optional")))))

(deftest op-help-keeps-compatibility-aliases-secondary
  (let [help (core/format-op-help :ls (get core/ops-registry :ls))]
    (testing "labels old spellings as compatibility inputs"
      (is (str/includes? help "Compatibility aliases: outline")))))

(deftest cat-help-documents-the-one-shot-read-contract
  (let [help (core/format-op-help :show-form
                                  (get core/ops-registry :show-form))]
    (is (str/starts-with? help "clj-surgeon :op cat"))
    (testing "all selectors and CLJC disambiguation are discoverable"
      (is (str/includes? help ":form"))
      (is (str/includes? help ":forms"))
      (is (str/includes? help ":line"))
      (is (str/includes? help ":contains"))
      (is (str/includes? help ":platform"))
      (is (str/includes? help "exactly one selector"))
      (is (str/includes? help "instead of reconstructing a sed range"))
      (is (str/includes? help "do not run :ls solely as a preflight"))
      (is (str/includes? help "distinctive text"))
      (is (str/includes? help "literal"))
      (is (not (str/includes? help "rg -n"))))
    (testing "the exact documented invocations are printed"
      (is (str/includes? help ":op :cat :file src/my/ns.clj :form transition!"))
      (is (str/includes? help ":forms '[transition! validate-state]'"))
      (is (str/includes? help ":op :cat :file src/my/ns.clj :line 1134"))
      (is (str/includes? help ":op :cat :file src/my/ns.clj :contains :finish"))
      (is (str/includes? help "keyword-shaped values such as :finish remain literal text")))
    (testing "the old spelling is secondary"
      (is (str/includes? help "Compatibility aliases: show-form")))
    (testing "ambiguity fails closed"
      (is (str/includes? help "never chooses the first match"))
      (is (str/includes? help "all-or-nothing"))
      (is (str/includes? help "duplicate"))
      (is (str/includes? help "65,536")))))

(deftest replace-subform-apply-help-forbids-plan-editing
  (let [help (core/format-op-help :replace-subform!
                                  (get core/ops-registry :replace-subform!))]
    (is (str/includes? help "Do not edit the plan"))
    (is (str/includes? help "never chain it with application"))
    (is (str/includes? help "generate a new plan"))
    (is (str/includes? help "reviewed plan is the edit-level diff"))
    (is (str/includes? help "git diff"))
    (is (str/includes? help "do not probe for a Git worktree"))
    (is (str/includes? help ":replace-subform!"))))

(deftest replace-subform-help-teaches-one-shot-sibling-context
  (let [help (core/format-op-help :replace-subform
                                  (get core/ops-registry :replace-subform))]
    (is (str/includes? help "case key"))
    (is (str/includes? help ":cat :contains"))
    (is (str/includes? help "owner and context in one read"))))

(deftest lens-help-teaches-the-getter-updater-algebra-and-review-boundary
  (let [help (core/format-op-help :lens (get core/ops-registry :lens))]
    (is (str/includes? help "Compatibility aliases: q"))
    (is (str/includes? help "EDN pipeline"))
    (is (str/includes? help "[:form transition]"))
    (is (str/includes? help "[:find :finish]"))
    (is (str/includes? help ":right"))
    (is (str/includes? help "[:span 2]"))
    (is (str/includes? help "[:partition-all 2]"))
    (is (str/includes? help "shorter final span is explicit"))
    (is (str/includes? help "[:find cond] :up :outermost"))
    (is (str/includes? help "first outer sibling is already known"))
    (is (str/includes? help "[:replace-span :finish"))
    (is (str/includes? help "preserves comments and whitespace between peers"))
    (is (str/includes? help "[:replace (assoc state :status :complete)]"))
    (is (str/includes? help "emits a plan and never writes source"))
    (is (str/includes? help "Apply the reviewed plan separately"))))

(deftest edit-and-apply-help-do-not-teach-redundant-plan-rereads
  (let [edit-help (core/format-op-help :edit (get core/ops-registry :edit))
        apply-help (core/format-op-help :replace-subform!
                                        (get core/ops-registry :replace-subform!))]
    (is (str/includes? edit-help "do not reread the saved plan file"))
    (is (str/includes? apply-help "do not reopen the saved plan"))))

(deftest find-subform-help-teaches-one-shot-file-wide-structural-match
  (let [help (core/format-op-help :find-subform
                                  (get core/ops-registry :find-subform))]
    (is (str/starts-with? help "clj-surgeon :op match-form"))
    (is (str/includes? help "Compatibility aliases: find-subform, grep-form"))
    (is (str/includes? help "Omit :inside for file-wide structural search"))
    (is (str/includes? help ":op :match-form"))
    (is (str/includes? help "not a regular expression"))
    (is (str/includes? help "matches exactly one subtree"))
    (is (str/includes? help "There is no variadic wildcard"))
    (is (str/includes? help ":match '(loop _ _)'"))))

(deftest extraction-help-teaches-the-failure-atomic-and-guarded-undo-contract
  (let [plan-help (core/format-op-help
                    :extract (get core/ops-registry :extract))
        apply-help (core/format-op-help
                     :extract! (get core/ops-registry :extract!))
        undo-help (core/format-op-help
                    :undo-extract! (get core/ops-registry :undo-extract!))]
    (is (str/includes? plan-help "dependency-minimal"))
    (is (str/includes? plan-help "quoted-Var proof"))
    (is (str/includes? plan-help ":require-policy"))
    (is (str/includes? plan-help ":copy-all"))
    (is (str/includes? apply-help ":receipt-out"))
    (is (str/includes? apply-help ":require-policy"))
    (is (str/includes? apply-help ":copy-all"))
    (is (str/includes? apply-help "target-requires"))
    (is (str/includes? apply-help "remaining-source-callers"))
    (is (str/includes? apply-help "Unsupported require shapes refuse"))
    (is (str/includes? apply-help "quoted-var-references"))
    (is (str/includes? apply-help "parses them, hash-fences the source"))
    (is (str/includes? apply-help "roll back"))
    (is (str/includes? apply-help ":undo-extract!"))
    (is (str/includes? undo-help "both result files still match"))
    (is (str/includes? undo-help "refuses before writing"))))

;; ============================================================
;; parse-val — string to value (pure)
;; ============================================================

(deftest parse-val-keywords
  (is (= :ls (core/parse-val ":ls")))
  (is (= :edn (core/parse-val ":edn")))
  (is (= :cljs (core/parse-val ":cljs"))))

(deftest parse-val-booleans
  (is (= true (core/parse-val "true")))
  (is (= false (core/parse-val "false"))))

(deftest parse-val-preserves-numeric-strings-for-operation-specific-meaning
  (testing "the generic parser does not corrupt numeric grep terms or identifiers"
    (is (= "1134" (core/parse-val "1134")))
    (is (= "-7" (core/parse-val "-7")))
    (is (= "12.5" (core/parse-val "12.5")))
    (is (= "12a" (core/parse-val "12a")))))

(deftest parse-val-edn-vectors
  (is (= '[foo bar] (core/parse-val "[foo bar]")))
  (is (= '[a] (core/parse-val "[a]"))))

(deftest parse-val-edn-maps
  (is (= {:a 1} (core/parse-val "{:a 1}"))))

(deftest parse-val-strings-pass-through
  (is (= "src/my/ns.clj" (core/parse-val "src/my/ns.clj")))
  (is (= "postgres|jdbc" (core/parse-val "postgres|jdbc"))))

;; ============================================================
;; parse-args — arg list to opts map (pure)
;; ============================================================

(deftest parse-args-basic-key-value-pairs
  (is (= {:op :ls :file "src/my/ns.clj"}
         (core/parse-args [":op" ":ls" ":file" "src/my/ns.clj"]))))

(deftest parse-args-multiple-args
  (is (= {:op :mv :file "state.clj" :form "foo" :before "bar" :dry-run true}
         (core/parse-args [":op" ":mv" ":file" "state.clj"
                           ":form" "foo" ":before" "bar" ":dry-run" "true"]))))

(deftest parse-args-with-deps-boolean
  (is (= {:op :mv :file "state.clj" :form "foo" :before "bar"
          :with-deps true}
         (core/parse-args [":op" ":mv" ":file" "state.clj"
                           ":form" "foo" ":before" "bar"
                           ":with-deps" "true"]))))

(deftest mv-help-documents-guard-and-dependency-alias
  (let [help (core/format-op-help :mv (get core/ops-registry :mv))]
    (is (str/includes? help "with-deps"))
    (is (str/includes? help "mv-with-deps"))
    (is (str/includes? help "presets :with-deps true"))
    (is (str/includes? help "dependency guards"))
    (is (str/includes? help "Safe workflow:"))
    (is (str/includes? help "Always preview plain :mv"))
    (is (str/includes? help ":would-strand-dependencies"))
    (is (str/includes? help ":would-strand-users"))
    (is (str/includes? help ":recommended-command"))
    (is (str/includes? help ":apply-command"))
    (is (str/includes? help ":added-forms"))
    (is (str/includes? help ":move-order"))
    (is (str/includes? help "not a saved, hash-bound plan"))
    (is (str/includes? help
                       ":mv :file src/my/ns.clj :form foo :before bar :dry-run true"))))

(deftest parse-args-edn-vector-arg
  (is (= {:op :extract :file "src/s.clj" :forms '[distill refine] :to "src/d.clj"}
         (core/parse-args [":op" ":extract" ":file" "src/s.clj"
                           ":forms" "[distill refine]" ":to" "src/d.clj"]))))

(deftest parse-args-preserves-structural-forms-for-the-lens-parser
  (is (= "[:button {:onclick \"\\x27\"}]"
         (:with (core/parse-args [":op" ":replace-subform"
                                  ":with" "[:button {:onclick \"\\x27\"}]"]))))
  (is (= "(inc 1) (inc 2)"
         (:match (core/parse-args [":op" ":find-subform"
                                   ":match" "(inc 1) (inc 2)"])))))

(deftest parse-args-preserves-query-for-one-bounded-lens-parser
  (let [query "[[:form transition] [:find :finish] :right]"]
    (is (= query
           (:query (core/parse-args [":op" ":q" ":file" "state.clj"
                                     ":query" query]))))))

(deftest parse-args-preserves-contains-as-literal-text
  (testing "EDN-shaped search text is not reinterpreted"
    (doseq [literal [":finish" "nil" "42" "true" "[status]"]]
      (is (= literal
             (:contains (core/parse-args [":op" ":cat"
                                          ":file" "state.clj"
                                          ":contains" literal])))
          literal))))

(deftest parse-args-help-flag-standalone
  (is (= {:help true}
         (core/parse-args ["--help"]))))

(deftest parse-args-dash-h-standalone
  (is (= {:help true}
         (core/parse-args ["-h"]))))

(deftest parse-args-help-with-op
  (is (= {:op :ls :help true}
         (core/parse-args [":op" ":ls" "--help"]))))

(deftest parse-args-help-before-op
  (is (= {:op :ls :help true}
         (core/parse-args ["--help" ":op" ":ls"]))))

(deftest parse-args-empty
  (is (= {} (core/parse-args []))))

(deftest parse-args-help-stripped-from-pairs
  (testing "--help doesn't interfere with key-value pairing"
    (is (= {:op :ls :file "foo.clj" :help true}
           (core/parse-args [":op" ":ls" "--help" ":file" "foo.clj"])))))

;; ============================================================
;; Subprocess CLI tests — actual command-line parsing end-to-end
;;
;; Shells out to `bb -m clj-surgeon.core` as a separate process,
;; testing exactly what a user or agent would see.
;; ============================================================

(def ^:private project-src
  "Absolute path to this project's src/ dir, for subprocess classpath."
  (let [this-file (io/file "test/clj_surgeon/help_test.clj")]
    (str (.getAbsolutePath
           (io/file (.getParentFile (.getParentFile (.getParentFile this-file))) "src")))))

(defn- run-cli
  "Run clj-surgeon CLI as subprocess, return {:exit :out :err}."
  [& args]
  (apply proc/shell {:out :string :err :string :continue true}
         "bb" "-cp" project-src "-m" "clj-surgeon.core" args))

(defn- run-outline-cli-without-semantic-enrichment [operation]
  (let [fixture (java.io.File/createTempFile "clj-surgeon-help-outline" ".clj")]
    (try
      (spit fixture "(defn dispatch-sentinel [x] x)\n")
      (run-cli ":op" operation ":file" (.getAbsolutePath fixture))
      (finally
        (.delete fixture)))))

;; --- No args → global help ---

(deftest cli-no-args-shows-help
  (let [{:keys [exit out]} (run-cli)]
    (testing "exits successfully"
      (is (zero? exit)))
    (testing "shows global help with usage line"
      (is (str/includes? out "clj-surgeon"))
      (is (str/includes? out "Usage:")))
    (testing "shows all categories"
      (is (str/includes? out "Read-only"))
      (is (str/includes? out "Write"))
      (is (str/includes? out "CLJC")))
    (testing "shows quick start examples"
      (is (str/includes? out "Quick start:")))))

;; --- --help flag → global help ---

(deftest cli-help-flag-shows-help
  (let [{:keys [exit out]} (run-cli "--help")]
    (testing "exits successfully"
      (is (zero? exit)))
    (testing "shows same global help as no-args"
      (is (str/includes? out "Usage:"))
      (is (str/includes? out "Read-only")))))

(deftest cli-op-help-name-shows-global-help
  (doseq [op [":help" "help"]]
    (let [{:keys [exit out err]} (run-cli ":op" op)]
      (is (zero? exit) (str op " stderr: " err))
      (is (str/includes? out "Usage:") op)
      (is (str/includes? out "Quick start:") op))))

(deftest cli-version-is-a-zero-exit-edn-orientation-call
  (let [result (run-cli "--version")
        version (edn/read-string (:out result))]
    (is (= 0 (:exit result)) (:err result))
    (is (= {:tool "clj-surgeon" :version "0.1.0"} version))
    (is (str/blank? (:err result)))
    (is (str/includes? (core/format-global-help core/ops-registry)
                       "clj-surgeon --version"))))

(deftest cli-dash-h-flag-shows-help
  (let [{:keys [exit out]} (run-cli "-h")]
    (testing "-h works like --help"
      (is (zero? exit))
      (is (str/includes? out "Usage:")))))

;; --- Per-op --help ---

(deftest cli-op-help-shows-details
  (let [{:keys [exit out]} (run-cli ":op" ":ls" "--help")]
    (testing "exits successfully"
      (is (zero? exit)))
    (testing "shows op name"
      (is (str/includes? out "clj-surgeon :op ls")))
    (testing "shows description"
      (is (str/includes? out "List forms")))
    (testing "shows required args"
      (is (str/includes? out ":file"))
      (is (str/includes? out "(required)")))
    (testing "shows examples"
      (is (str/includes? out "Examples:")))))

(deftest cli-op-help-with-pair
  (let [{:keys [exit out]} (run-cli ":op" ":extract" "--help")]
    (testing "shows see-also for plan/execute pair"
      (is (zero? exit))
      (is (str/includes? out "See also: :op extract!")))))

(deftest cli-op-help-for-alias
  (let [{:keys [exit out]} (run-cli ":op" ":tree" "--help")]
    (testing "alias resolves and shows help for canonical op"
      (is (zero? exit))
      (is (str/includes? out "Map namespaces across a directory tree")))))

;; --- Unknown op ---

(deftest cli-unknown-op-shows-error
  (let [{:keys [exit out]} (run-cli ":op" ":bogus")]
    (testing "returns a failing exit status and prints an EDN error"
      (is (pos? exit))
      (is (= :unknown-operation (:error-type (edn/read-string out)))))
    (testing "error message mentions the bad op"
      (is (str/includes? out "Unknown op: :bogus")))
    (testing "error lists valid ops from registry"
      (is (str/includes? out ":ls"))
      (is (str/includes? out ":extract"))
      (is (str/includes? out ":cljc-merge")))))

;; --- --help with unknown op ---

(deftest cli-help-unknown-op-is-an-error
  (let [{:keys [exit out]} (run-cli ":op" ":bogus" "--help")]
    (testing "does not disguise an invalid command as successful help"
      (is (pos? exit))
      (is (= :unknown-operation (:error-type (edn/read-string out)))))))

;; --- Normal dispatch still works ---

(deftest cli-normal-dispatch-works
  (let [{:keys [exit out]} (run-outline-cli-without-semantic-enrichment ":ls")]
    (testing "normal :ls dispatch returns outline"
      (is (zero? exit))
      (is (str/includes? out "dispatch-sentinel"))
      (is (str/includes? out ":forms")))))

;; --- Alias dispatch still works ---

(deftest cli-alias-dispatch-works
  (let [{:keys [exit out]} (run-outline-cli-without-semantic-enrichment ":outline")]
    (testing ":outline alias dispatches same as :ls"
      (is (zero? exit))
      (is (str/includes? out "dispatch-sentinel")))))

(deftest cli-documented-string-op-dispatch-works
  (let [{:keys [exit out]} (run-cli ":op" "ls-tree" ":dir" "src")]
    (testing "-main accepts documented bare op values"
      (is (zero? exit))
      (is (str/includes? out "clj_surgeon/core.clj"))
      (is (str/includes? out "ns: clj-surgeon.core")))))
