# Captain's Log: The Extraction Created Its Own Room

Date: 2026-08-26

## Mission

Test whether the compiled extraction route can generalize the earlier compact
editor win to a materially different historical refactor: move 15 formatting
forms out of Sessionize's 4,594-line `views.clj` into a new nested namespace,
preserve callers and comments, make exactly one private helper public, and pass
the affected lint gate.

The fixture freezes the real historical before/after pair. Exact bytes remain
useful secondary evidence, but correctness means lossless Clojure syntax after
removing only whitespace and commas. Comment, metadata, reader-discard, string,
regex, form-order, and source-anchor changes remain failures.

## The first immutable Anvil pair was ugly and useful

Commit `895647f`, dev-a, Sol/high, MCP-first, one replicate:

| Arm | Complete wall | Harness correct | Exact | Actions | Failed mutations | Route adherent |
|---|---:|---:|---:|---:|---:|---:|
| MCP plan + apply | 79.679s | false | false | 5 | 1 | false |
| Native | 114.959s | false | false | 5 | 0 | true |

Those booleans hid two different stories.

- The MCP receipt hashes were byte-identical to both frozen after files. Its
  `views.clj` false negative came from raw `node/sexpr` equality: reader-generated
  symbols inside unchanged `#(...)` forms are not stable across independent
  parses. The lossless syntax comparison was true.
- Native made a genuinely different program surface. It omitted the required
  `:as format` alias and omitted the destination namespace docstring.
- MCP's first required plan call safely refused with
  `target-parent-not-found`. The destination was
  `src/cfp_scheduler_killer/views/format.clj`, and the `views/` directory did
  not exist. A shell `mkdir` plus a repeated plan made the mandated two-call
  route impossible before the model reached the edit.

The 79.679s versus 114.959s timing is therefore not yet a claimed win. The
first cohort is retained as immutable evidence of route and scoring defects.

## Four ratchets fell directly out of the failure

### 1. A new namespace owns safe parent creation

Planning now resolves a nested absent target under its nearest existing real,
project-confined ancestor without creating anything. Apply creates each still
absent directory shallowest-first, records only directories it actually
created, and includes them in the extraction receipt.

Undo and verification rollback remove the new file and those directories in
reverse order. If a path appears between plan and commit, apply refuses rather
than adopting or deleting another actor's directory.

### 2. Formatting is scoped to created namespaces

Extraction no longer sends every future source and caller file through the
whole-file formatter. Structural deletion, require insertion, and guarded
caller edits already preserve surrounding bytes. Only newly created files need
whole-file formatting.

This removes broad unrelated reindentation from the transaction and shrinks
formatter work from two files to one on the frozen case.

### 3. The source require is inserted where a human expects it

The target namespace libspec is inserted before the first lexically greater
namespace instead of always being appended after third-party dependencies.
The insertion preserves existing trivia. A comment-bearing require clause
keeps the old append behavior so a new entry cannot silently capture a comment
that described its former neighbor.

### 4. Lossless syntax is the correctness authority

The portfolio scorer still publishes raw semantic equality as diagnostic
evidence, but `correct` now follows the lossless syntax comparison. A permanent
test proves that unchanged anonymous-function source with whitespace drift is
correct even when generated-symbol identity makes raw `sexpr` equality false.
Existing tests still reject comment loss or alteration, reader-discard loss,
metadata loss, string changes, regex changes, and parse failures.

## Local full-fixture proof after the ratchets

The real 15-form fixture was replayed through the hot project nREPL:

- plan: successful; exact required public form was `not-blank`;
- apply: successful, 15 edits across two files, no refusal;
- apply wall: 6.494s;
- formatter: one file, 153ms, zero additional target changes;
- destination namespace: byte-exact against the historical target;
- existing source: meaning-preserved, presentation-only drift;
- clj-kondo: 0 errors, 17 inherited warnings;
- undo and deliberately failed verification both restored the original source
  and removed the new file plus newly created directory.

Warm focused proof: path tests 1/10, extraction tests 6/48, and the public MCP
extraction witnesses passed. Cold `make test` passed 610 core tests / 5,240
assertions and 228 MCP tests / 1,872 assertions, plus heap, cclsp, stdio,
benchmark, skill, and evidence gates.

## What this changes in the hill climb

The complete extraction decision can now genuinely fit the intended route:

```text
exact roots + destination
        |
        v
one snapshot-bound plan  ---> complete manifest + public_forms + next_call
        |
        v
one atomic apply          ---> create directories + format target + receipt
        |
        v
one proportional lint gate
```

The next Anvil cohort must run from the new immutable commit, include both
orders, and retain every failed arm. Success means both correctness and route
adherence before speed is interpreted. The hypothesis is now sharper: the win
comes from compiling directory creation, dependency planning, visibility,
source require placement, target formatting, mutation, and rollback into two
model-visible calls—not from making any individual file operation faster.

## First clean Anvil replay: correct and 2.45x faster than an incorrect native arm

Commit `bb3253d`, dev-a, Sol/high, MCP-first, one frozen replicate:

| Arm | Complete wall | Correct | Exact | Actions | Shell / MCP | Refusals | Failed mutations | Route adherent |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| MCP plan + apply | 51.322s | true | false | 3 | 1 / 2 | 0 | 0 | true |
| Native | 125.971s | false | false | 6 | 5 / 0 | 0 | 0 | true |

The MCP result preserved meaning and presentation in the existing source and
matched the new destination file byte-for-byte. Its non-exact result is only
presentation-level drift in `views.clj`. Native did not preserve the required
historical result, so the 2.45x ratio is a complete-task outcome, not a
matched-correctness speed ratio. Native would need additional diagnosis and
repair time to become comparable.

The route repair itself is independently visible. Compared with the first
immutable MCP arm, complete wall fell from 79.679s to 51.322s (35.6%), actions
fell from five to three, and the refusal plus failed mutation both disappeared.
The model executed the intended plan/apply transaction once each.

Server-owned work was a minority of complete wall:

- plan inspection: 5.860s;
- apply total: 6.963s, including 6.958s in the kernel;
- formatter: one created file, zero formatter changes, 1.009s;
- complete task: 51.322s.

This narrows the next hill: formatter startup is no longer the dominant cost in
this case. Approximately 38.5 seconds lie outside the two server calls. The
remaining opportunity is to shorten caller deliberation, payload construction,
and the required foreground verification route while preserving the two-call
compiled decision. A native-first fresh replay remains necessary before this
single run becomes a stable performance claim.

## The counterbalance held

The native-first replay used a fresh worktree and fresh arm callers at the same
commit and on the same Sol/high seat:

| Order | Arm | Complete wall | Correct | Actions | Shell / MCP | Refusals | Route adherent |
|---|---|---:|---:|---:|---:|---:|---:|
| MCP first | MCP | 51.322s | true | 3 | 1 / 2 | 0 | true |
| MCP first | native | 125.971s | false | 6 | 5 / 0 | 0 | true |
| Native first | native | 121.194s | false | 5 | 4 / 0 | 0 | true |
| Native first | MCP | 48.559s | true | 3 | 1 / 2 | 0 | true |

Across the two frozen orderings, MCP was correct 2/2 and native was correct
0/2. Median complete wall was 49.941s for MCP and 123.583s for native, a 2.47x
complete-task advantage. MCP used three actions in both runs; native used five
or six. MCP had zero refusals and zero failed mutations in both runs.

The outcome is stable enough to retain the architecture, but the claim remains
precise: this is a repeated complete-task win against native attempts that did
not finish correctly. It is stronger than a latency microbenchmark because the
correct historical refactor was delivered, and weaker than a matched-correctness
speed ratio because no native arm reached the same result.

The performance decomposition also replicated:

| MCP phase | MCP-first | Native-first |
|---|---:|---:|
| Plan inspection | 5.860s | 5.855s |
| Apply total | 6.963s | 6.852s |
| Formatter within apply | 1.009s | 0.928s |
| Complete task | 51.322s | 48.559s |

The compiled server work is remarkably stable. Roughly 36–38.5 seconds per arm
remain outside plan and apply. That is now the dominant hill: the caller must
recognize the extraction shape, construct one complete intent, consume the
receipt, and stop. Further formatter engineering cannot create the desired next
multiple here; caller-side route compression and a cheaper planning contract
can.

The retained product decision is therefore:

1. Keep snapshot-bound extraction plan/apply, directory ownership, explicit
   visibility intent, scoped formatting, and lossless correctness scoring.
2. Keep the two-call route as the behavioral target; do not add adaptive
   recovery phases to the successful path.
3. Hill-climb the 36–38.5 seconds of model-visible deliberation next, using the
   frozen fixture and both orderings as regression evidence.
4. Continue reporting exact bytes as secondary evidence, not as the correctness
   authority when only whitespace or commas differ.

## Captain's after-action assessment

### Wins

This is the first retained historical extraction where the compiled Surgeon
route is both materially faster and more reliable than the native control. It
is not a toy replacement: fifteen real forms moved out of a 4,594-line
namespace into a newly created nested namespace while preserving comments and
meaning, updating dependencies, changing exactly one helper's visibility, and
returning an atomic verification and rollback receipt.

The stronger architectural result is route compression. Both successful arms
used one snapshot-bound plan and one atomic apply. No discovery loop, repair
call, failed mutation, or speculative retry entered the successful path. The
counterbalance showed that this result did not depend on which arm ran first.

The failed first cohort also paid for permanent improvements rather than being
discarded as noise:

- missing nested parents became an owned, reversible part of extraction;
- formatter scope shrank to the newly created namespace;
- require placement became deterministic without reassigning comments;
- correctness stopped depending on unstable reader-generated symbol identity.

### Losses and honest limits

The native controls were wrong in both runs. The observed 2.47x ratio is
therefore a complete-task outcome, not a matched-correctness latency ratio. It
is stronger evidence than a microbenchmark—the correct result was actually
delivered—but it does not tell us how long a correct native route would take.

The cohort is still only two counterbalanced runs on one dev-a Sol/high seat.
Agent Bridge composer defects prevented the intended dev-b/dev-c replication;
those runs never started and were excluded. The existing source was
meaning-preserved with presentation-only drift rather than byte-identical,
while the new destination was byte-identical.

The implementation is also modular rather than small by line count. Safe
directory ownership requires state-change refusal, receipts, rollback, and
undo. Those mechanics earned their cost, but they should not become permission
to grow an adaptive successful-path engine.

Finally, Surgeon has not made the task instantaneous. Plan and apply consume
about 12.7 seconds; another 36–38.5 seconds remains in caller recognition,
deliberation, intent construction, and stopping behavior. That is the next
dominant hill.

### What I am most proud of

We did not grade the ugly first run on a curve or rewrite its history. We kept
the refusal and false result immutable, separated a real product defect from a
scorer defect, and repaired both without weakening the safety contract. The
second cohort then succeeded through exactly the route we had claimed should
exist.

Surgeon can now *create its own room*. Given the musical phrase—exact roots,
destination, and intent—the model plays one planning chord and one mutation
chord. The instrument owns directory creation, namespace construction,
dependency movement, visibility, formatting, verification, rollback, and the
receipt. That is the church-organ editing experience this quest was seeking:
the model decides meaning; the tool makes the complete mechanical change safe,
fast, and final.
